// === App Shell ===
const app = {
  currentGame: null,
  games: [
    {
      id: 'memory',
      name: '记忆翻牌',
      icon: '🧠',
      desc: '翻开卡片找到相同的配对，考验你的记忆力！',
      tags: ['记忆', '配对'],
      module: MemoryGame
    },
    {
      id: 'snake',
      name: '贪吃蛇',
      icon: '🐍',
      desc: '经典贪吃蛇游戏，吃掉食物越长越大！',
      tags: ['经典', '街机'],
      module: SnakeGame
    },
    {
      id: '2048',
      name: '2048',
      icon: '🔢',
      desc: '滑动合并数字方块，挑战达到 2048！',
      tags: ['数字', '策略'],
      module: Game2048
    },
    {
      id: 'minesweeper',
      name: '扫雷',
      icon: '💣',
      desc: '经典扫雷游戏，避开地雷找出所有安全格！',
      tags: ['经典', '推理'],
      module: MinesweeperGame
    },
    {
      id: 'puzzle',
      name: '滑块拼图',
      icon: '🧩',
      desc: '移动滑块还原图片顺序，经典的 15 拼图！',
      tags: ['逻辑', '排序'],
      module: PuzzleGame
    },
    {
      id: 'tetris',
      name: '俄罗斯方块',
      icon: '🧱',
      desc: '经典俄罗斯方块，消除整行得分升级！',
      tags: ['经典', '街机'],
      module: TetrisGame
    }
  ],

  init() {
    this.renderGameGrid();
    this.bindEvents();
  },

  renderGameGrid() {
    const grid = document.getElementById('gameGrid');
    grid.innerHTML = this.games.map(g => `
      <div class="game-card" data-game="${g.id}">
        <div class="game-icon">${g.icon}</div>
        <div class="game-name">${g.name}</div>
        <div class="game-desc">${g.desc}</div>
        <div class="game-tags">${g.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
      </div>
    `).join('');
  },

  bindEvents() {
    document.getElementById('gameGrid').addEventListener('click', (e) => {
      const card = e.target.closest('.game-card');
      if (card) {
        const gameId = card.dataset.game;
        this.openGame(gameId);
      }
    });

    document.getElementById('backBtn').addEventListener('click', () => {
      this.closeGame();
    });
  },

  openGame(gameId) {
    const gameDef = this.games.find(g => g.id === gameId);
    if (!gameDef) return;

    this.currentGame = gameDef;

    document.getElementById('homePage').style.display = 'none';
    document.getElementById('gamePage').style.display = 'block';
    document.getElementById('backBtn').style.display = 'block';
    document.getElementById('gameTitle').textContent = gameDef.name;

    const controls = document.getElementById('gameControls');
    controls.innerHTML = `
      <div class="game-stats" id="gameStats"></div>
      <button class="btn small" id="gameRestart">重新开始</button>
    `;
    document.getElementById('gameRestart').addEventListener('click', () => {
      this.startGame();
    });

    document.getElementById('gameArea').innerHTML = '';
    this.startGame();
  },

  closeGame() {
    if (this.currentGame && this.currentGame.module && this.currentGame.module.destroy) {
      this.currentGame.module.destroy();
    }
    this.currentGame = null;
    document.getElementById('homePage').style.display = 'block';
    document.getElementById('gamePage').style.display = 'none';
    document.getElementById('backBtn').style.display = 'none';
    document.getElementById('gameArea').innerHTML = '';
  },

  startGame() {
    if (!this.currentGame) return;
    const area = document.getElementById('gameArea');
    area.innerHTML = '';
    this.currentGame.module.init(area, this.updateStats.bind(this));
  },

  updateStats(stats) {
    const el = document.getElementById('gameStats');
    if (el) {
      el.innerHTML = Object.entries(stats).map(([k, v]) =>
        `<div class="stat">${k}: <span>${v}</span></div>`
      ).join('');
    }
  }
};

document.addEventListener('DOMContentLoaded', () => app.init());
